from flask import Flask, render_template, request, flash, redirect, url_for

app = Flask(__name__)
app.secret_key = "secret_key"

# Sample data for stock management
stock_items = [
    {
        "id": 1,
        "name": "Navigation System",
        "description": "Premium car navigation system",
        "quantity": 10,
        "price": 99.99
    },
    {
        "id": 2,
        "name": "Car Seat Cover",
        "description": "Luxury car seat cover",
        "quantity": 15,
        "price": 49.99
    }
]

@app.route('/')
def index():
    return render_template("index.html", stock_items=stock_items)

@app.route('/update/<int:item_id>', methods=['POST'])
def update_stock(item_id):
    new_quantity = request.form.get("quantity")
    try:
        new_quantity = int(new_quantity)
        for item in stock_items:
            if item["id"] == item_id:
                item["quantity"] = new_quantity
                flash(f"Stock for {item['name']} updated successfully!", "success")
                break
        else:
            flash("Item not found!", "error")
    except ValueError:
        flash("Invalid quantity!", "error")
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
